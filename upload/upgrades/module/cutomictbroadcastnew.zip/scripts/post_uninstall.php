<?php

if (!defined('sugarEntry'))
    define('sugarEntry', true);

post_uninstall();

function post_uninstall() {

    // Unlink Files and remove folder :-- 
    $files = array(
        'custom/Extension/modules/Administration/Ext/Administration/ce_config_tab.php',
        'custom/Extension/modules/Administration/Ext/Language/en_us.ce_config_tab.php',
        'custom/Extension/application/Ext/EntryPointRegistry/customIctbroadcast_EntryPoint.php',
        'custom/include/generic/SugarWidgets/SugarWidgetSubPanelTopIctbroadcastBtn.php',
        'include/MVC/View/views/view.list.php',
        'custom/modules/Accounts/views/view.list.php',
        'custom/modules/Cases/views/view.list.php',
        'custom/modules/Contacts/views/view.list.php',
        'custom/modules/Leads/views/view.list.php',
        'custom/modules/Meetings/views/view.list.php',
        'custom/modules/Opportunities/views/view.list.php',
        'custom/modules/Project/views/view.list.php',
        'custom/modules/Prospects/views/view.list.php',
        'modules/CE_custom_ictbroadcast/',
            // End 
    );
    foreach ($files as $file) {
        if (file_exists($file) && is_dir($file)) {
            recursiveRemove($file);
        } elseif (file_exists($file) && is_file($file)) {
            unlink($file);
        }
    }

    // End 

    $file = 'include/MVC/View/views/view.list_cebkp.php';
    $newfile = 'include/MVC/View/views/view.list.php';

    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    // restore the original files
    $file = 'custom/modules/Accounts/views/view.list_cebkp.php';
    $newfile = 'custom/modules/Accounts/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    // restore the original files
    $file = 'custom/modules/Cases/views/view.list_cebkp.php';
    $newfile = 'custom/modules/Cases/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    // restore the original files
    $file = 'custom/modules/Contacts/views/view.list_cebkp.php';
    $newfile = 'custom/modules/Contacts/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    // restore the original files
    $file = 'custom/modules/Leads/views/view.list_cebkp.php';
    $newfile = 'custom/modules/Leads/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    // restore the original files
    $file = 'custom/modules/Meetings/views/view.list_cebkp.php';
    $newfile = 'custom/modules/Meetings/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    // restore the original files
    $file = 'custom/modules/Opportunities/views/view.list_cebkp.php';
    $newfile = 'custom/modules/Opportunities/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    // restore the original files
    $file = 'custom/modules/Project/views/view.list_cebkp.php';
    $newfile = 'custom/modules/Project/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    // restore the original files
    $file = 'custom/modules/Prospects/views/view.list_cebkp.php';
    $newfile = 'custom/modules/Prospects/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
}

function recursiveRemove($dir) {
    $structure = glob(rtrim($dir, "/") . '/*');
    if (is_array($structure)) {
        foreach ($structure as $file) {
            if (is_dir($file))
                recursiveRemove($file);
            elseif (is_file($file))
                unlink($file);
        }
    }
    rmdir($dir);
}

global $db;

$select_query = "SELECT module,subpanel FROM custom_ictbroadcast_subpanel_tbl";
$query = $db->query($select_query);
$module_Subpanel = array();
while ($result = $db->fetchByAssoc($query)) {
    $module_Subpanel = explode(',', $result['subpanel']);
    $module_Extfolder_path = 'custom/modules/' . $result['module'] . '/Ext/Layoutdefs/layoutdefs.ext.php';
    if (file_exists($module_Extfolder_path)) {
        chmod($module_Extfolder_path, 0777);
        unlink($module_Extfolder_path);
    }
    foreach ($module_Subpanel as $sub) {
        $folder_path = 'custom/Extension/modules/' . $result['module'] . '/Ext/Layoutdefs/';
        chmod($folder_path, 0777);
        $exist_exportFile = '_override' . $sub . '_customIctbroadcastBtn.php';
        $exist_exportFile = $folder_path . $exist_exportFile;
        chmod($exist_exportFile, 0777);
        if (file_exists($exist_exportFile)) {
            unlink($exist_exportFile);
        }
    }
}
if ($_REQUEST['remove_tables'] == 'true') {
    $sql_module_1 = "DROP table custom_ictbroadcast_modules_tbl";
    $sql_module_2 = "DROP table custom_ictbroadcast_subpanel_tbl";
     $sql_module_3 = "DROP table custom_ictbroadcast_integration_tbl";
    $db->query($sql_module_1);
    $db->query($sql_module_2);
    $db->query($sql_module_3);
}

