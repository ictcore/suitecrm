<?php
// Ignore fields from export.
// give field name in uppercase in array.
// E.g :- $excludeColumns['Module-Name']['Subpanel-Setup-Name'] = array('FIELDNAME');
$excludeColumns['Accounts']['documents'] = array('OBJECT_IMAGE');
$excludeColumns['Contacts']['documents'] = array('OBJECT_IMAGE');
$excludeColumns['Cases']['documents'] = array('OBJECT_IMAGE');
$excludeColumns['Opportunities']['documents'] = array('OBJECT_IMAGE');




