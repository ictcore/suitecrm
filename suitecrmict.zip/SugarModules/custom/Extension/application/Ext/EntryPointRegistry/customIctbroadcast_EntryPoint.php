<?php

$entry_point_registry['ictbroadcastCustom'] = array(
       'file' => 'modules/CE_custom_ictbroadcast/ictbroadcastCustom.php', 
    'auth' => true
    );

