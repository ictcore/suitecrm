<?php

ini_set('zlib.output_compression', 'Off');

ob_start();
require_once('include/export_utils.php');
global $app_strings, $db;
$module = $_REQUEST['module'];
$focus = BeanFactory::getBean($module);
$records = explode(",", $_REQUEST['uid']);

if (file_exists('custom/modules/' . $module . '/metadata/listviewdefs.php')) {
    require_once('custom/modules/' . $module . '/metadata/listviewdefs.php');
} else {
    require_once('modules/' . $module . '/metadata/listviewdefs.php');
}
$list_viewDefs = $listViewDefs;

// New changes regarding selected fields for export
$getExportFieldsFromDB = "Select sequence,export_fields from ce_custom_export where module = '{$module}' and view_type='module' order by sequence asc";
$query = $db->query($getExportFieldsFromDB);
$exportFieldsArr = array();
$exportFieldsArrAsSeq = array();
while ($getFields = $db->fetchByAssoc($query)) {
    $exportFieldsArr[$module][strtoupper($getFields['export_fields'])]['label'] = $this->bean->field_name_map[$getFields['export_fields']]['vname'];
    $exportFieldsArr[$module][strtoupper($getFields['export_fields'])]['default'] = true;
}

if (!empty($exportFieldsArr)) {
    $list_viewDefs = $exportFieldsArr;
}
// End 
if (file_exists('modules/CE_custom_ictbroadcast/ce_ignorefields_lv.php')) {
    require_once('modules/CE_custom_ictbroadcast/ce_ignorefields_lv.php');
} else {
    $excludeColumns = array();
}
$excludeColumnsArray = (is_null($excludeColumns[$module])) ? array() : $excludeColumns[$module];
foreach ($excludeColumnsArray as $hidefields) {
    unset($list_viewDefs[$module][$hidefields]);
}

$filter = array();
$all_fields_in_module = array_keys($focus->field_defs);
foreach ($all_fields_in_module as $field) {
    $filter[$field] = true;
}
if ($focus->bean_implements('ACL')) {
    if (!ACLController::checkAccess($focus->module_dir, 'export', true)) {
        ACLController::displayNoAccess();
        sugar_die('');
    }
}

$targetModuleLang = return_module_language('en_us', $focus->module_dir);

$limit = -1;
//if all is selected
if (is_null($_REQUEST['uid'])) {
    $limit = 2000;
}

if (!is_null($_REQUEST['uid'])) {
    $id_arr = array();
    foreach ($records as $id) {
        $id_arr[] = '"' . $id . '"';
    }
    $record_id = implode(",", $id_arr);
    $where = "{$focus->table_name}.id in ({$record_id})";
} elseif (isset($_REQUEST['all'])) {
    $where = '';
} else {
    if (!empty($_REQUEST['current_post'])) {
        $ret_array = generateSearchWhere($module, $_REQUEST['current_post']);

        $where = $ret_array['where'];
        $searchFields = $ret_array['searchFields'];
    } else {
        $where = '';
    }
}
 if($where != "")
   $where = " and ".$where;
 else
   $where = '';
$params['custom_where'] = $where." group by {$focus->table_name}.id ";

require_once('include/ListView/ListViewData.php');
$listObject = new ListViewData();
$exportListRows = $listObject->getListViewData($focus, '', 0, $limit, $filter, $params);

if (!is_null($_REQUEST['uid'])) {
    foreach ($exportListRows['data'] as $key => $dataArray) {
        if (!in_array($dataArray['ID'], $records)) {
            unset($exportListRows['data'][$key]);
        }
    }
}
$finalExportData = array();
foreach ($exportListRows['data'] as $id => $exportListRow) {
    foreach ($list_viewDefs[$module] as $fieldName => $options) {
        if (!is_null($targetModuleLang[$options['label']])) {
            $label = $targetModuleLang[$options['label']];
        } else {
            if (!is_null($app_strings[$options['label']])) {
                $label = $app_strings[$options['label']];
            } else {
                $label = $options['label'];
            }
        }
        if (isset($label) && $label != "" && isset($options['default']) && $options['default'] == true) {
            $finalExportData[$id][$label] = trim(strip_tags($exportListRow[strtoupper($fieldName)]));
    }
}
}

echo $_REQUEST['ictbroadcastOpt'];
if ($_REQUEST['ictbroadcastOpt'] == 'excel') {
    exportToExcel($module, $finalExportData);
} else {
    exportToPDF($module, $finalExportData);
}

function exportToPDF($module, $fields) {
    global $app_list_strings;
    $name = $app_list_strings['moduleList'][$module];
    require_once('modules/CE_custom_ictbroadcast/pdf/config/lang/eng.php');
    require_once('modules/CE_custom_ictbroadcast/pdf/tcpdf.php');

    // create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // set header and footer fonts
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    //set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

    //set image scale factor
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

    //set some language-dependent strings
    $pdf->setLanguageArray($l);

    // set font
    $pdf->SetFont('helvetica', '', 11);
    $pdf->AddPage('L');


    $tbl = '<table cellspacing="0" cellpadding="1" border="0" width="100%" align="center">
		<tr>
			<td><h3>' . $name . '</h3></td>
		</tr>
	</table>';

    $pdf->writeHTML($tbl, true, false, false, false, '');

    $tbl = '<table width="100%" border="1" cellspacing="0" cellpadding="1">
              <thead><tr><th style="width:5%;"><strong>No</strong></th>';
    foreach ($fields[0] as $title => $value) {
        $tbl .= '<th><strong>' . $title . '</strong></th>';
    }

    $tbl .= '</tr></thead>';

    foreach ($fields as $index => $row) {
        $count = $index + 1;
        $tbl .= '<tbody><tr nobr="true"><td style="width:5%;">' . $count . '</td>';
        foreach ($row as $title => $value) {
            $tbl .= '<td>' . $value . '</td>';
        }
        $tbl .= '</tr></tbody>';
    }
    $tbl .= '</table>';

    $pdf->writeHTML($tbl, true, false, false, false, '');
    //clear buffer first
    ob_clean();
    //Close and output PDF document
    $pdf->Output($name . '.pdf', 'D');
}

function exportToExcel($module, $finalExportData) {
    global $app_list_strings;
    $filename = $app_list_strings['moduleList'][$module];
    if ($_REQUEST['members'] == true)
        $filename .= '_' . 'members';

    function cleanData(&$str) {
        $str = preg_replace("/\t/", "\\t", $str);
        $str = preg_replace("/\r?\n/", " ", $str);
        $str = preg_replace("/&nbsp;/", "", $str);
        if (strstr($str, '"'))
            $str = '"' . str_replace('"', '""', $str) . '"';
    }

    //clean the ob before writing to xl
    ob_clean();
    header("Content-Disposition: attachment; filename={$filename}.xls");
    header("Content-Type: application/vnd.ms-excel");

    $flag = false;
    foreach ($finalExportData as $row) {
        if (!$flag) {
            // display field/column names as first row
            echo implode("\t", array_keys($row)) . "\r\n";
            $flag = true;
        }
        array_walk($row, 'cleanData');
        //echo implode("\t", array_values($row)) . "\r\n";
         echo htmlspecialchars_decode(implode("\t", array_values($row)),ENT_QUOTES) . "\r\n";
    }
}

sugar_cleanup(true);
?>
