$(function () {
    $('#droppable').droppable({
        accept: '.field-div',
        drop: function (event, ui) {
            $(this).append(ui.draggable.removeAttr("style").addClass('sel-field-div').removeClass('field-div ui-state-default draggable ui-draggable'));
            $(ui.draggable).append('<img onclick="removeElement(this);" src="modules/CE_custom_ictbroadcast/image/delete.gif">');
            $('.sel-field-div').draggable({
                handle: "sel-field-div",
                appendTo: "body",
                connectToSortable: '.sortable-ul',
                revert: 'invalid'
            });
        }
    });
    $('#droppable').sortable();
    $("#droppable").disableSelection();
    $('.draggable').draggable({
        handle: "div",
        appendTo: "body",
        connectToSortable: '.sortable-ul',
        revert: 'invalid'
    });
});

function removeElement(ele) {
    var t = $(ele).closest('div');
    $(t).addClass('field-div');
    $(t).addClass('le_field');
    $(t).addClass('field-div');
    $(t).addClass('ui-state-default');
    $(t).addClass('draggable');
    $(t).addClass('ui-draggable');
    $(t).removeClass('sel-field-div');
    $(t).find('img').remove();
     $(t).css('position','relative');
    $('#fieldlist').append($(t));
    $(t).draggable({
        handle: "div",
        appendTo: "body",
        connectToSortable: '.sortable-ul',
        revert: 'invalid'
    });
}